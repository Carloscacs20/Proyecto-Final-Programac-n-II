
// Paquete de conexión a la base de datos
package org.example.database;

// Importación de librerías
// Importación de la clase Connection del paquete java.sql 
// Importación de la clase DriverManager del paquete java.sql sirve para manejar la conexión a la base de datos
import java.sql.Connection;
import java.sql.DriverManager;

// Clase de conexión a la base de datos
public class Conexion {
    // Atributos de la clase
    // URL de la base de datos
    // Usuario de la base de datos
    // Contraseña de la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/manejo_empresa";
    private static final String USER = "root"; // Tu usuario de MySQL
    private static final String PASSWORD = "sasa"; // Tu contraseña de MySQL

    // Método de conexión a la base de datos
    // Retorna un objeto de tipo Connection
    // Si la conexión es exitosa, retorna un objeto de tipo Connection
    // Si la conexión no es exitosa, retorna un objeto nulo
    public static Connection conectar() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}