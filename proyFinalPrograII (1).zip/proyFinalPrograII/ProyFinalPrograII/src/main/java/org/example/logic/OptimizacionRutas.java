package org.example.logic;

import org.example.database.Conexion;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/*Esta clase gestiona las rutas registradas en la base de datos, permitiendo:
 - Generar reportes de problemas.
 - Calcular y optimizar rutas.
 - Actualizar estados de rutas.
 - Mostrar rutas actuales.
 
 Requiere una conexión a la base de datos, la cual se establece mediante la clase `Conexion`.
 Utiliza componentes de la librería `javax.swing` para interactuar con el usuario.*/


public class OptimizacionRutas {
    // Genera un reporte de problemas en la base de datos.
    // problema Descripción del problema a reportar.
    // Se inserta un nuevo registro en la tabla `reporte_problemas` con la descripción del problema.
    // Se muestra un mensaje de confirmación al usuario.
    public void generarReporteProblemas(String problema) {
        String query = "INSERT INTO reporte_problemas (descripcion) VALUES (?)";
        try (Connection conn = Conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, problema);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Reporte de problema generado: " + problema);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al generar reporte de problemas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Calcula las rutas óptimas basándose en los datos actuales.
    // Las rutas se optimizan según criterios predefinidos y se actualizan sus estados.
    // Se muestra un reporte con las rutas actuales y sus posibles optimizaciones.
    // Se muestra un mensaje de confirmación al usuario.
    public void calcularRutasOptimas() {
        String query = "SELECT * FROM rutas";
        StringBuilder resultado = new StringBuilder("Rutas actuales y posibles optimizaciones:\n");

        try (Connection conn = Conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String origen = rs.getString("origen");
                String destino = rs.getString("destino");
                String estado = rs.getString("estado");
                resultado.append(String.format("Ruta ID: %d | Origen: %s | Destino: %s | Estado: %s\n", id, origen, destino, estado));

                // Lógica de optimización
                String nuevoEstado = optimizarRuta(origen, destino);
                actualizarRutas(id, nuevoEstado);
                resultado.append(String.format("Ruta ID %d estado: %s\n", id, nuevoEstado));
            }
            JOptionPane.showMessageDialog(null, resultado.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al calcular rutas óptimas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Actualiza el estado de una ruta en la base de datos.
    // idRuta ID de la ruta a actualizar.
    // nuevoEstado Nuevo estado de la ruta.
    // Se actualiza el estado de la ruta con el ID especificado.
    // Se muestra un mensaje de confirmación al usuario.
    public void actualizarRutas(int idRuta, String nuevoEstado) {
        String query = "UPDATE rutas SET estado = ? WHERE id = ?";
        try (Connection conn = Conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nuevoEstado);
            stmt.setInt(2, idRuta);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ruta actualizada: ID " + idRuta + " nuevo estado: " + nuevoEstado);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar rutas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Simula la optimización de una ruta.
    // Origen de la ruta.
    // Destino de la ruta.
    // Devuelve un mensaje con la optimización realizada.
    private String optimizarRuta(String origen, String destino) {
        // Lógica de optimización basada en las rutas específicas
        // Se simula con condiciones arbitrarias
        if (origen.equalsIgnoreCase("Centro") && destino.equalsIgnoreCase("Norte")) { // equalsIgnoreCase para ignorar mayúsculas y minúsculas en la comparación de cadenas de texto
            return "Optimizada para menor congestión";
        } else if (origen.equalsIgnoreCase("Sur") && destino.equalsIgnoreCase("Este")) {
            return "Optimizada con menor distancia";
        } else if (origen.equalsIgnoreCase("Este") && destino.equalsIgnoreCase("Oeste")) {
            return "Optimizada con menor tiempo";
        } else {
            return "Optimizada estándar";
        }
    }

    // Método para mostrar las rutas actuales
    // Muestra las rutas registradas en la base de datos.
    // Cada ruta se muestra con su ID, origen, destino y estado.
    // Se muestra en un cuadro de diálogo.
    // En caso de error, se muestra un mensaje de error.
    public void mostrarRutasActuales() {
        String query = "SELECT * FROM rutas";
        StringBuilder resultado = new StringBuilder("Rutas actuales:\n");
        
        try (Connection conn = Conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String origen = rs.getString("origen");
                String destino = rs.getString("destino");
                String estado = rs.getString("estado");
                resultado.append(String.format("Ruta ID: %d | Origen: %s | Destino: %s | Estado: %s\n", id, origen, destino, estado));
            }
            JOptionPane.showMessageDialog(null, resultado.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar rutas actuales: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
