package org.example.main;

import org.example.models.*;
import org.example.menu.Menu;
import javax.swing.*;

// Se usa swing para mostrar mensajes de diálogo

public class Main {
    public static void main(String[] args) {
        // Solicitar credenciales de inicio de sesión

        String idUsuario = JOptionPane.showInputDialog(null, "Ingrese su ID de usuario:");
        String contraseña = JOptionPane.showInputDialog(null, "Ingrese su contraseña:");

        // Crear un nuevo usuario y autenticar

        Usuario autenticado = Usuario.iniciarSesion(idUsuario, contraseña);

        // Si el usuario se autentica correctamente, mostrar el menú principal
        // y permitir realizar los procesos 
        // de lo contrario, mostrar un mensaje de error
        // y cerrar la aplicación
        if (autenticado != null) {
            // Mostrar menú
            Menu.mostrarMenu(autenticado);

            
        } else {
            System.out.println("Autenticación fallida.");
        }
    }
}