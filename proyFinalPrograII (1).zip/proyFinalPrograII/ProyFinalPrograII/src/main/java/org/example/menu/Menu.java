package org.example.menu;

import org.example.models.*;
import org.example.logic.OptimizacionRutas;

import javax.swing.*;
import java.util.List;

public class Menu {

    // Método principal para mostrar el menú según el cargo
    public static void mostrarMenu(Usuario usuario) {
        if (usuario == null) {
            JOptionPane.showMessageDialog(null, "Usuario no encontrado.");
            return;
        }

        // Bucle para mostrar el menú hasta dar la opción de salir
        while (true) {
            String menuOpciones;
            int opcion;

            switch (usuario.getCargo().toUpperCase()) {
                case "CLIENTE":
                    menuOpciones = "MENU CLIENTE\n1. Ver pedidos anteriores\n2. Ver pedido actual\n3. Salir";
                    opcion = obtenerOpcion(menuOpciones);
                    if (opcion == 3) return;
                    procesarOpcionCliente(usuario, opcion);
                    break;

                case "CONDUCTOR":
                    menuOpciones = "MENU CONDUCTOR\n1. Ver rutas asignadas\n2. Calcular rutas óptimas\n3. Reportar problema\n4. Salir";
                    opcion = obtenerOpcion(menuOpciones);
                    if (opcion == 4) return;
                    procesarOpcionConductor(usuario, opcion);
                    break;

                case "ADMINISTRADOR":
                    menuOpciones = "MENU ADMINISTRADOR\n1. Ver rutas actuales\n2. Ver pedidos anteriores\n3. Revisar informes\n4. Reportar problema\n5. Salir";
                    opcion = obtenerOpcion(menuOpciones);
                    if (opcion == 5) return;
                    procesarOpcionAdmin(usuario, opcion);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Cargo no reconocido.");
                    return;
            }
        }
    }

    // Método para obtener la opción del usuario
    private static int obtenerOpcion(String menu) {
        try {
            String opcionStr = JOptionPane.showInputDialog(null, menu);
            return Integer.parseInt(opcionStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ingrese una opción válida.");
            return -1;
        }
    }

    // Procesar las opciones del menú del cliente
    private static void procesarOpcionCliente(Usuario usuario, int opcion) {
        switch (opcion) {
            case 1 -> {
                List<Entregas> entregas = Entregas.obtenerEntregasPorCliente(usuario.getId());
                mostrarLista(entregas);
            }
            case 2 -> {
                List<Entregas> entregasEnCamino = Entregas.obtenerEntregasEnCamino(usuario.getId());
                mostrarLista(entregasEnCamino);
            }
            default -> JOptionPane.showMessageDialog(null, "Opción no válida.");
        }
    }

    // Procesar las opciones del menú del conductor
    private static void procesarOpcionConductor(Usuario usuario, int opcion) {
        OptimizacionRutas optimizacionRutas = new OptimizacionRutas();

        switch (opcion) {
            case 1 -> optimizacionRutas.mostrarRutasActuales();
            case 2 -> {
                JOptionPane.showMessageDialog(null, "Calculando rutas óptimas...");
                optimizacionRutas.calcularRutasOptimas();
            }
            case 3 -> {
                String reporte = JOptionPane.showInputDialog(null, "Ingrese el reporte del problema:");
                optimizacionRutas.generarReporteProblemas(reporte);
                JOptionPane.showMessageDialog(null, "Reporte generado correctamente.");
            }
            default -> JOptionPane.showMessageDialog(null, "Opción no válida.");
        }
    }

    // Procesar las opciones del menú del administrador
    private static void procesarOpcionAdmin(Usuario usuario, int opcion) {
        OptimizacionRutas optimizacionRutas = new OptimizacionRutas();

        switch (opcion) {
            case 1 -> optimizacionRutas.mostrarRutasActuales();
            case 2 -> {
                List<Entregas> pedidosAnteriores = Entregas.obtenerTodosLosPedidos();
                mostrarLista(pedidosAnteriores);
            }
            case 3 -> {
                List<String> informes = ReporteProblemas.obtenerTodosLosReportes();
                mostrarLista(informes);
            }
            case 4 -> {
                try {
                    String idEntregaStr = JOptionPane.showInputDialog(null, "Ingrese el ID de la entrega:");
                    int idEntrega = Integer.parseInt(idEntregaStr);
                    String reporte = JOptionPane.showInputDialog(null, "Ingrese el reporte del problema:");
                    Entregas.actualizarReporte(idEntrega, reporte);
                    JOptionPane.showMessageDialog(null, "Reporte actualizado correctamente.");
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "ID de entrega inválido.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            default -> JOptionPane.showMessageDialog(null, "Opción no válida.");
        }
    }

    // Método para mostrar una lista de elementos
    private static <T> void mostrarLista(List<T> lista) {
        if (lista == null || lista.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay datos disponibles.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (T item : lista) {
                sb.append(item).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }
}
