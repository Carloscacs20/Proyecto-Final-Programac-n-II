package org.example.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.database.Conexion;


/* Esta clase se encarga de gestionar las entregas de los pedidos almacenados en una base de datos.
 Permite realizar operaciones como consultar entregas por cliente, actualizar reportes, 
 verificar el estado de entregas y detectar posibles problemas en la base de datos.
 */

public class Entregas {
    // Atributos de la clase
    private int idEntrega; // Identificador único de la entrega
    private String idCliente; // Identificador del cliente asociado a la entrega
    private String idConductor; // Identificador del conductor encargado de la entrega
    private String estado; // Estado actual de la entrega
    private String horaEntrega; // Hora estimada o registrada de la entrega
    private String reporte; // Descripción de problemas o notas relacionadas con la entrega

    // Constructor
    // Se inicializan los atributos con los valores recibidos
    public Entregas(int idEntrega, String idCliente, String idConductor, String estado, String horaEntrega, String reporte) {
        this.idEntrega = idEntrega;
        this.idCliente = idCliente;
        this.idConductor = idConductor;
        this.estado = estado;
        this.horaEntrega = horaEntrega;
        this.reporte = reporte;
    }

    // Método para obtener todas las entregas de un cliente
    // Obtiene todas las entregas realizadas a un cliente específico.
    // idCliente Identificador del cliente.
    // Lista de objetos Entregas asociadas al cliente.
    public static List<Entregas> obtenerEntregasPorCliente(String idCliente) {
        List<Entregas> entregas = new ArrayList<>();
        try {
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            String query = "SELECT * FROM entregas WHERE idcliente = '" + idCliente + "'";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                entregas.add(new Entregas(
                        rs.getInt("identregas"),
                        rs.getString("idcliente"),
                        rs.getString("idconductor"),
                        rs.getString("estado"),
                        rs.getString("horaentrega"),
                        rs.getString("reporte")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Imprime la excepción 
        }
        return entregas;
    }

    // Método para obtener entregas "EN CAMINO"
    // idCliente Identificador del cliente.
    // Lista de objetos Entregas con estado "En camino".
    public static List<Entregas> obtenerEntregasEnCamino(String idCliente) {
        List<Entregas> entregas = new ArrayList<>();
        try {
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            String query = "SELECT * FROM entregas WHERE idcliente = '" + idCliente + "' AND estado = 'En camino'";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                entregas.add(new Entregas(
                        rs.getInt("identregas"),
                        rs.getString("idcliente"),
                        rs.getString("idconductor"),
                        rs.getString("estado"),
                        rs.getString("horaentrega"),
                        rs.getString("reporte")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return entregas;
    }

    // Método para obtener todos los pedidos
    // Lista de todos los objetos Entregas.
    public static List<Entregas> obtenerTodosLosPedidos() {
        List<Entregas> entregas = new ArrayList<>();
        try {
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            String query = "SELECT * FROM entregas";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                entregas.add(new Entregas(
                        rs.getInt("identregas"),
                        rs.getString("idcliente"),
                        rs.getString("idconductor"),
                        rs.getString("estado"),
                        rs.getString("horaentrega"),
                        rs.getString("reporte")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entregas;
    }

    // Método para actualizar el reporte
    // idPedido Identificador de la entrega. 
    // Nuevo contenido del reporte.
    // public static void actualizarReporte(String idCliente, String reporte) {
    //     try {
    //         Connection conn = Conexion.conectar();
    //         PreparedStatement ps = conn.prepareStatement(
    //         "UPDATE entregas SET reporte = ? WHERE idcliente = ? AND estado = 'En camino'");
    //         ps.setString(1, reporte);
    //         ps.setString(2, idCliente);
    //         ps.executeUpdate();
    //     } catch (SQLException e) {
    //         e.printStackTrace();
    //     }
    // }
    public static void actualizarReporte(int idEntrega, String reporte) {
        try {
            // Establece la conexión con la base de datos
            Connection conn = Conexion.conectar();
            
            // Prepara la consulta SQL para actualizar el reporte en la tabla entregas
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE entregas SET reporte = ? WHERE id = ?");
            
            // Asigna los valores a los parámetros de la consulta
            ps.setString(1, reporte); // Asigna el nuevo valor para la columna 'reporte'
            ps.setInt(2, idEntrega); // Asigna el id de la entrega que se quiere modificar
            
            // Ejecuta la actualización
            int filasActualizadas = ps.executeUpdate();
            
            // Verifica si se modificaron filas y muestra un mensaje en consecuencia
            if (filasActualizadas > 0) {
                System.out.println("Reporte actualizado correctamente para la entrega con ID: " + idEntrega);
            } else {
                System.out.println("No se encontró una entrega con el ID especificado.");
            }
        } catch (SQLException e) {
            // Maneja posibles errores al ejecutar la consulta
            System.err.println("Error al actualizar el reporte: " + e.getMessage());
        }
    }
    

    // Muestra el estado de una entrega específica por su ID.
    // idPedido Identificador único del pedido.
    public static void mostrarEstadoEntrega(int idPedido) { 
        try {
            // Establece una conexión con la base de datos.
            Connection conn = Conexion.conectar(); 
            
            // Crea un objeto Statement para ejecutar consultas SQL.
            Statement st = conn.createStatement(); 
            
            // Define la consulta SQL para obtener los datos de la tabla 'entregas' con el ID especificado.
            String query = "SELECT * FROM entregas WHERE identregas = " + idPedido; 
            
            // Ejecuta la consulta y almacena el resultado en un ResultSet.
            ResultSet rs = st.executeQuery(query); 
            
            // Verifica si la consulta devolvió algún resultado.
            if (rs.next()) { 
                // Obtiene y muestra el ID del pedido.
                System.out.println("Pedido ID: " + rs.getInt("identregas")); 
                
                // Obtiene y muestra el estado del pedido.
                System.out.println("Estado: " + rs.getString("estado")); 
                
                // Obtiene y muestra la hora de entrega del pedido.
                System.out.println("Ubicación: " + rs.getString("horaentrega")); 
            } else {
                // Informa si el pedido no fue encontrado en la base de datos.
                System.out.println("Pedido no encontrado."); 
            }
        } catch (SQLException e) {
            // Captura y muestra cualquier error que ocurra durante la ejecución de la consulta.
            e.printStackTrace(); 
        }
    }

    // Método para mostrar el estado general de todas las entregas
    public static void mostrarEstadoGeneral() {
        List<Entregas> entregas = obtenerTodosLosPedidos();
        for (Entregas entrega : entregas) {
            System.out.println(entrega);
        }
    }

    // Metodo para verificar posibles problemas en la base de datos, como campos nulos en las entregas.
    public static void verificarProblemasBaseDatos() {
        List<Entregas> entregas = obtenerTodosLosPedidos();
        boolean problemasEncontrados = false;
        for (Entregas entrega : entregas) {
            if (entrega.estado == null || entrega.horaEntrega == null) {
                System.out.println("Problema encontrado en el pedido ID: " + entrega.idEntrega);
                problemasEncontrados = true;
            }
        }
        if (!problemasEncontrados) {
            System.out.println("No se encontraron problemas con la base de datos.");
        }
    }

    // Método para mostrar la entrega como texto (toString)
    // String que describe los datos de la entrega.
    @Override
    public String toString() {
        return "Entrega{" +
                "idEntrega=" + idEntrega +
                ", idCliente='" + idCliente + '\'' +
                ", idConductor='" + idConductor + '\'' +
                ", estado='" + estado + '\'' +
                ", horaEntrega='" + horaEntrega + '\'' +
                ", reporte='" + reporte + '\'' +
                '}';
    }
}
