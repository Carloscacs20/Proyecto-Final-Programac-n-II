// package org.example.models;

// public class Pedido {
//     private int idPedido;
//     private String estado; // Ejemplo: "En camino", "Entregado", "Retrasado"
//     private String ubicacion; // Ejemplo: "A 5 km del destino"

//     public Pedido(int idPedido, String estado, String ubicacion) {
//         this.idPedido = idPedido;
//         this.estado = estado;
//         this.ubicacion = ubicacion;
//     }

//     public int getIdPedido() {
//         return idPedido;
//     }

//     public String getEstado() {
//         return estado;
//     }

//     public void setEstado(String estado) {
//         this.estado = estado;
//     }

//     public String getUbicacion() {
//         return ubicacion;
//     }

//     public void setUbicacion(String ubicacion) {
//         this.ubicacion = ubicacion;
//     }
// }
// package org.example.models;


// public class Pedido {
//     // Atributos
//     private int idPedido;
//     private String estado;
    
//     private String ubicacion;

//     // Constructor para inicializar un objeto de la clase Pedido con valores específicos.
//     public Pedido(int idPedido, String estado, String ubicacion) {
//         this.idPedido = idPedido; // Asigna el ID del pedido.
//         this.estado = estado; // Asigna el estado del pedido.
//         this.ubicacion = ubicacion; // Asigna la ubicación del pedido.
//     }

//     // Método para obtener el ID del pedido.
//     public int getIdPedido() {
//         return idPedido;
//     }

//     // Método para obtener el estado del pedido.
//     public String getEstado() {
//         return estado;
//     }

//     // Método para asignar o modificar el estado del pedido.
//     public void setEstado(String estado) {
//         this.estado = estado;
//     }

//     // Método para obtener la ubicación del pedido.
//     public String getUbicacion() {
//         return ubicacion;
//     }

//     // Método para asignar o modificar la ubicación del pedido.
//     public void setUbicacion(String ubicacion) {
//         this.ubicacion = ubicacion;
//     }
// }
