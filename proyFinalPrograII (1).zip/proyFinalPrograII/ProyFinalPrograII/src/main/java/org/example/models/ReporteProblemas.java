package org.example.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.database.Conexion;

/*Esta clase representa un reporte de problemas registrado en el sistema.
 Cada reporte tiene un identificador único y una descripción del problema.
 */
public class ReporteProblemas {
    private int id; // Identificador único del reporte
    private String descripcion; // Descripción del problema reportado

    // Constructor de la clase ReporteProblemas
    // Inicializa un objeto de la clase con un ID y una descripción
    public ReporteProblemas(int id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }

public static List<String> obtenerTodosLosReportes() {
    // Lista para almacenar los valores de la columna 'reporte' de la tabla 'entregas'
    List<String> reportes = new ArrayList<>();
    try {
        // Establece una conexión a la base de datos
        Connection conn = Conexion.conectar();
        // Crea un objeto Statement para ejecutar la consulta SQL
        Statement st = conn.createStatement();
        // Define la consulta SQL para seleccionar la columna 'reporte' de la tabla 'entregas'
        String query = "SELECT reporte FROM entregas";
        // Ejecuta la consulta y guarda los resultados en un ResultSet
        ResultSet rs = st.executeQuery(query);
        // Itera por cada fila del resultado
        while (rs.next()) {
            // Agrega el valor de la columna 'reporte' a la lista
            reportes.add(rs.getString("reporte")); // Obtiene el valor de la columna 'reporte' como cadena
        }
    } catch (SQLException e) {
        // Imprime la traza de la excepción si ocurre un error al ejecutar la consulta
        e.printStackTrace();
    }
    // Retorna la lista de reportes
    return reportes;
}


// Método para mostrar el reporte como texto (toString)
// Devuelve una representación en forma de texto del objeto
@Override
public String toString() {
    // Retorna una cadena con los valores de los atributos del objeto
    return "ReporteProblemas{" +
            "id=" + id + // Muestra el valor del atributo 'id'
            ", descripcion='" + descripcion + '\'' + // Muestra el valor del atributo 'descripcion'
            '}';
}
}
