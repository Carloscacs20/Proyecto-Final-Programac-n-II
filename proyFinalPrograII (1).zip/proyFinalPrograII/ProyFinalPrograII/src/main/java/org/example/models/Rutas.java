package org.example.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.database.Conexion;

public class Rutas {
    private int id;
    private String origen;
    private String destino;
    private String estado;
    private String idConductor;

    // Constructor
    public Rutas(int id, String origen, String destino, String estado, String idConductor) {
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.estado = estado;
        this.idConductor = idConductor;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdConductor() {
        return idConductor;
    }

    public void setIdConductor(String idConductor) {
        this.idConductor = idConductor;
    }

    // Método para obtener todas las rutas asignadas a un conductor
    public static List<Rutas> obtenerRutasPorConductor(String idConductor) {
        List<Rutas> rutas = new ArrayList<>();
        try {
            //Se realiza la conexión con la base de datos
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            //Se busca mediante el id de conductor todas las rutas disponibles
            String query = "SELECT * FROM rutas WHERE idconductor = '" + idConductor + "'";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                rutas.add(new Rutas(
                    //Se crea un objeto rutas con los datos
                        rs.getInt("id"),
                        rs.getString("origen"),
                        rs.getString("destino"),
                        rs.getString("estado"),
                        rs.getString("idconductor")
                ));
            }
        } catch (SQLException e) {
        }
        return rutas;
    }

    // Método para obtener la ruta actual de un conductor
    public static Rutas obtenerRutaActual(String idConductor) {
        Rutas ruta = null;
        try {
            //Se realiza la conexión con la base de datos
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            //Se busca mediante el id del conductor las rutas que estan en estado "En progreso"
            String query = "SELECT * FROM rutas WHERE idconductor = '" + idConductor + "' AND estado = 'En progreso'";
            ResultSet rs = st.executeQuery(query);
            if (rs.next()) {
                //Se crea un objeto Rutas con los datos
                ruta = new Rutas(
                        rs.getInt("id"),
                        rs.getString("origen"),
                        rs.getString("destino"),
                        rs.getString("estado"),
                        rs.getString("idconductor")
                );
            }
        } catch (SQLException e) {
        }
        return ruta;
    }

    // Método para actualizar el reporte de una ruta
    public static void actualizarReporte(String idConductor, String reporte) {
        try {
            //Se realiza la conexión con la base de datos
            Connection conn = Conexion.conectar();
            PreparedStatement ps = conn.prepareStatement(
            //Se actualiza los datos de la tabla rutas, siendo ingresado los datos después
            "UPDATE rutas SET reporte = ? WHERE idconductor = ? AND estado = 'En progreso'");
            ps.setString(1, reporte); //Se solicita el reporte
            ps.setString(2, idConductor); //Se coloca el id del conductor
            ps.executeUpdate(); //Se actualiza la base de datos
        } catch (SQLException e) {
        }
    }

    // Método para mostrar la ruta como texto (toString)
    //Se sobreescribe el metodo toString para que aparezcan los datos de distinta forma
    @Override
    public String toString() {
        return "Ruta{" +
                "id=" + id +
                ", origen='" + origen + '\'' +
                ", destino='" + destino + '\'' +
                ", estado='" + estado + '\'' +
                ", idConductor='" + idConductor + '\'' +
                '}';
    }
}