package org.example.models;
import org.example.database.Conexion;
import java.sql.*;

public class Usuario {
    // Atributos
    private String id;
    private String contraseña;
    private String cargo; //Cargo del usuario, puede ser CLIENTE, CONDUCTOR o ADMINISTRADOR

    // Constructor
    public Usuario(String id, String contraseña, String cargo) {
        this.id = id;
        this.contraseña = contraseña;
        this.cargo = cargo;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getContraseña() {
        return contraseña;
    }

    public String getCargo() {
        return cargo;
    }

    // Método de inicio de sesión
    public static Usuario iniciarSesion(String id, String contraseña) {
        try {
            //Se conecta con la base de datos
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            String login = "SELECT * FROM usuarios WHERE idusuarios = '" + id + "' AND pwdusuarios = '" + contraseña + "'";
            ResultSet rs = st.executeQuery(login);
            //Si se obtiene un resultado, se crea un objeto Usuario con los datos obtenidos
            if (rs.next()) {
                return new Usuario(
                    rs.getString("idusuarios"),
                    rs.getString("pwdusuarios"),
                    rs.getString("cargousuarios")
                );
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        //Se retorna null si no se encuentra un usuario con las credenciales
        return null;
    }
}
